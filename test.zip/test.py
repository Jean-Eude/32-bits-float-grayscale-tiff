import numpy as np
import cv2
import matplotlib.pyplot as plt
from scipy.ndimage import center_of_mass
from PIL import Image
import pandas as pd

# --- Générer une image avec lobe log-gaussien ---
def generate_user_like_beam_image(size=(256, 256),
                                  center_offset=(0, 0),
                                  beam_radius=55,
                                  vignette_strength=1.2,
                                  noise_level=0.01,
                                  vertical_bands=True):
    H, W = size
    cy, cx = H // 2 + center_offset[0], W // 2 + center_offset[1]
    Y, X = np.ogrid[:H, :W]
    img = np.zeros(size, dtype=np.float32)

    # Faisceau net au centre
    beam_mask = ((X - cx)**2 + (Y - cy)**2) <= beam_radius**2
    img[beam_mask] = 1.0

    # Lobe log-gaussien
    dist_sq = (X - cx)**2 + (Y - cy)**2
    log_gauss = np.exp(-np.log1p(dist_sq) / 100.0)  # log(1 + r^2)
    img += log_gauss

    # Vignettage (coins sombres)
    dist_y = np.abs(Y - H // 2) / (H // 2)
    dist_x = np.abs(X - W // 2) / (W // 2)
    vignette = np.clip(1 - vignette_strength * (dist_x**2 + dist_y**2)/2, 0, 1)
    img *= vignette

    # Bandes verticales
    if vertical_bands:
        for i in range(50, W, 100):
            img[:, i:i+2] *= 0.8

    # Bruit
    img += np.random.normal(scale=noise_level, size=img.shape)
    return np.clip(img, 0, 1)

# Fitting cercle (moindres carrés)
def fit_circle_least_squares(points):
    x = points[:, 0]
    y = points[:, 1]
    A = np.c_[2*x, 2*y, np.ones_like(x)]
    b = x**2 + y**2
    c, *_ = np.linalg.lstsq(A, b, rcond=None)
    xc, yc = c[0], c[1]
    r = np.sqrt(c[2] + xc**2 + yc**2)
    return xc, yc, r

# --- Génération de l'image ---
generated_img = generate_user_like_beam_image()
img_rgb = np.stack([generated_img]*3, axis=-1)

# --- Détection collimation ---
cy, cx = center_of_mass(generated_img)
hist, bins = np.histogram(generated_img, bins=256, range=(0, 1))
cum = np.cumsum(hist[::-1])[::-1]
idx = np.argmax(cum < cum[0] * 0.01)
threshold = bins[idx] if idx > 0 else 0.9
colli_mask = (generated_img >= threshold).astype(np.uint8)
colli_contours, _ = cv2.findContours(colli_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# --- Détection lobe (Canny) ---
edges = cv2.Canny((generated_img * 255).astype(np.uint8), 50, 150)
external_contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# --- Fitting cercles ---

# Collimation
colli_pts = np.vstack([cnt[:, 0, :] for cnt in colli_contours]) if colli_contours else np.array([])
if colli_pts.size > 0:
    xc1, yc1, r1 = fit_circle_least_squares(colli_pts)
    cv2.circle(img_rgb, (int(xc1), int(yc1)), int(r1), (1, 0.5, 0), 1)
    cv2.circle(img_rgb, (int(xc1), int(yc1)), 2, (1, 0, 1), -1)  # centre magenta

# Lobe global
lobe_pts = np.vstack([cnt[:, 0, :] for cnt in external_contours]) if external_contours else np.array([])
circle_data = []
if lobe_pts.size > 0:
    xc2, yc2, r2 = fit_circle_least_squares(lobe_pts)
    cv2.circle(img_rgb, (int(xc2), int(yc2)), int(r2), (0, 1, 1), 1)
    cv2.circle(img_rgb, (int(xc2), int(yc2)), 2, (0, 0, 1), -1)  # centre bleu

    # Masque du lobe pour stats
    H, W = generated_img.shape
    yy, xx = np.ogrid[:H, :W]
    dist = np.sqrt((xx - xc2)**2 + (yy - yc2)**2)
    lobe_mask = dist <= r2
    outer_mask = ~lobe_mask
    outer_vals = generated_img[outer_mask]
    mean_out = float(np.mean(outer_vals))
    std_out = float(np.std(outer_vals))

    circle_data.append({
        "type": "lobe",
        "center_x": float(xc2),
        "center_y": float(yc2),
        "radius": float(r2),
        "mean_outside": mean_out,
        "std_outside": std_out
    })

# --- Sauvegardes ---

# Image
image_path = "generated_and_fitted_image.png"
Image.fromarray((img_rgb * 255).astype(np.uint8)).save(image_path)

# CSV
df = pd.DataFrame(circle_data)
df.to_csv("lobe_circle_info.csv", index=False)

print("✅ Image sauvegardée :", image_path)
print("📄 CSV généré : lobe_circle_info.csv")
