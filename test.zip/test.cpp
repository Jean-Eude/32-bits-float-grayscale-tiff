#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

typedef vector<vector<float>> Image;

// Créer une image vide
Image createImage(int H, int W) {
    return Image(H, vector<float>(W, 0.0f));
}

// Distance carrée au centre
float distSq(int x, int y, int cx, int cy) {
    return float((x - cx) * (x - cx) + (y - cy) * (y - cy));
}

// Génère une image avec faisceau circulaire + log-gaussien
Image generateBeamImage(int H, int W, int beam_radius = 55) {
    int cx = W / 2;
    int cy = H / 2;
    Image img = createImage(H, W);

    for (int y = 0; y < H; ++y) {
        for (int x = 0; x < W; ++x) {
            float r2 = distSq(x, y, cx, cy);

            // Faisceau net
            if (r2 <= beam_radius * beam_radius)
                img[y][x] = 1.0f;

            // Lobe log-gaussien
            img[y][x] += exp(-log(1.0f + r2) / 100.0f);

            // Vignette (coins sombres)
            float dx = (x - W / 2.0f) / (W / 2.0f);
            float dy = (y - H / 2.0f) / (H / 2.0f);
            float vignette = max(0.0f, 1.0f - 1.2f * (dx * dx + dy * dy) / 2.0f);
            img[y][x] *= vignette;
        }
    }

    return img;
}

// Seuillage simple pour points brillants
vector<pair<int, int>> extractBrightPixels(const Image& img, float threshold = 0.5f) {
    vector<pair<int, int>> pts;
    int H = img.size();
    int W = img[0].size();
    for (int y = 0; y < H; ++y)
        for (int x = 0; x < W; ++x)
            if (img[y][x] > threshold)
                pts.emplace_back(x, y);
    return pts;
}

// Fitting de cercle par moindres carrés
bool fitCircle(const vector<pair<int, int>>& pts, float& cx, float& cy, float& r) {
    if (pts.size() < 3) return false;

    int N = pts.size();
    MatrixXf A(N, 3);
    VectorXf b(N);
    for (int i = 0; i < N; ++i) {
        float x = pts[i].first;
        float y = pts[i].second;
        A(i, 0) = 2 * x;
        A(i, 1) = 2 * y;
        A(i, 2) = 1;
        b(i) = x * x + y * y;
    }

    Vector3f sol = A.colPivHouseholderQr().solve(b);
    cx = sol(0);
    cy = sol(1);
    r = sqrt(sol(2) + cx * cx + cy * cy);
    return true;
}

// Sauvegarde PGM simple
void savePGM(const Image& img, const string& path) {
    int H = img.size();
    int W = img[0].size();
    ofstream ofs(path, ios::binary);
    ofs << "P5\n" << W << " " << H << "\n255\n";
    for (int y = 0; y < H; ++y)
        for (int x = 0; x < W; ++x)
            ofs.put(static_cast<unsigned char>(min(255.0f, img[y][x] * 255.0f)));
    ofs.close();
}

int main() {
    const int H = 256, W = 256;
    Image img = generateBeamImage(H, W);

    // Extraire les points brillants (le lobe)
    auto points = extractBrightPixels(img, 0.5f);

    float cx, cy, r;
    if (fitCircle(points, cx, cy, r)) {
        cout << "Cercle détecté : centre=(" << cx << ", " << cy << "), rayon=" << r << endl;
    } else {
        cout << "Erreur: pas assez de points pour ajuster un cercle.\n";
    }

    savePGM(img, "beam_loggauss.pgm");
    return 0;
}
